const biodata = {
    name: "Kelvin Wong",
    age: 25,
    hobbies: ['Swimming', 'Reading', 'Gaming'],
    isMarried: false,
    schoolList: [
        {schoolName: "SD Kristen Sunodia", yearIn: "2003", yearOut: "2009", major: null},
        {schoolName: "SMP Kristen Sunodia", yearIn: "2009", yearOut: "2012", major: null},
        {schoolName: "SMA Kristen Sunodia", yearIn: "2012", yearOut: "2015", major: "Science"},
        {schoolName: "Universitas Mulawarman", yearIn: "2015", yearOut: "2019", major: "Teknik Informatika"},
    ],
    skills: [
        {skillName: "Python", level: "Expert"},
        {skillName: "JavaScript", level: "Advanced"},
        {skillName: "CSS", level: "Beginner"},
    ],
    interestedInCoding: true
}

console.log(biodata)